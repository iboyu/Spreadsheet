#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#define size 50
#define row 5
#define col 5

int main()
{

    int i, j, left_bound_Num = 0, right_bound_Num = 0, left_column = 0, right_column = 0;
    char inbuf[size], insNum[size];
    double table[row][col], insertNum = 0, result;
    char operator[4];

    for (i = 0; i < row; i++)
    {
        for (j = 0; j < col; j++)
        {
            table[i][j] = 0.00;
        }
    }
    printf("\t A\t B\t C\t D\t E\n");
    for (i = 0; i < row; i++)
    {
        printf("%i\t", i + 1);
        for (j = 0; j < col; j++)
        {
            printf("%.2f\t", table[i][j]);
        }
        printf("\n");
    }
    printf("Please enter the command and do some math: (ADD, MUL, DEL, INS)\n");
    printf(">>");
    fgets(inbuf, size, stdin);
    sscanf(inbuf, "%c", inbuf);

    do
    {

        for (i = 0; i < strlen(inbuf); i++)
        {
            inbuf[i] = toupper(inbuf[i]);
        }

        for (i = 0; i < 3; i++)
        {
            operator[i] = inbuf[i];
        }
        operator[3] = '\0';
        left_bound_Num = inbuf[5] - '0';
        right_bound_Num = inbuf[8] - '0';
        if (inbuf[4] != inbuf[7] && inbuf[5] != inbuf[8])
        {
            printf("Invalid operation.\n");
        }

        else if (inbuf[4] < 'A' || inbuf[4] > 'E' || inbuf[7] < 'A' || inbuf[7] > 'E' || left_bound_Num < 0 || left_bound_Num > 5 || right_bound_Num < 0 || right_bound_Num > 5)
        {
            printf("Wrong range.\n");
        }
        else if (inbuf[4] == inbuf[7] && inbuf[5] == inbuf[8])
        {
            printf("Invalid cell.\n");
        }
        else
        {
            if (strlen(inbuf) > 12)
            {
                j = 0;
                for (i = 11; i < strlen(inbuf); i++)
                {
                    insNum[j] = inbuf[i];
                    j++;
                }
                insertNum = atof(insNum);
            }
        }

        if (inbuf[4] == 'A')
        {
            left_column = 0;
        }
        else if (inbuf[4] == 'B')
        {
            left_column = 1;
        }
        else if (inbuf[4] == 'C')
        {
            left_column = 2;
        }
        else if (inbuf[4] == 'D')
        {
            left_column = 3;
        }
        else if (inbuf[4] == 'E')
        {
            left_column = 4;
        }
        if (inbuf[7] == 'A')
        {
            right_column = 0;
        }
        else if (inbuf[7] == 'B')
        {
            right_column = 1;
        }
        else if (inbuf[7] == 'C')
        {
            right_column = 2;
        }
        else if (inbuf[7] == 'D')
        {
            right_column = 3;
        }
        else if (inbuf[7] == 'E')
        {
            right_column = 4;
        }

        if (strcmp(operator, "ADD") == 0)
        {
            result = 0.00;
            if (inbuf[4] == inbuf[7])
            {
                for (i = left_bound_Num - 1; i < right_bound_Num; i++)
                {
                    result += table[i][left_column];
                }
            }
            else
            {
                for (i = left_column; i <= right_column; i++)
                {
                    result += table[left_bound_Num - 1][i];
                }
            }
            printf(">> result  %.2f\n", result);
        }
        else if (strcmp(operator, "MUL") == 0)
        {
            result = 1.00;
            if (inbuf[4] == inbuf[7])
            {
                for (i = left_bound_Num - 1; i < right_bound_Num; i++)
                {
                    result *= table[i][left_column];
                }
            }
            else
            {
                for (i = left_column; i <= right_column; i++)
                {
                    result *= table[left_bound_Num - 1][i];
                }
            }
            printf(">> result  %.2f\n", result);
        }
        else if (strcmp(operator, "DEL") == 0)
        {
            if (inbuf[4] == inbuf[7])
            {
                for (i = left_bound_Num - 1; i < right_bound_Num; i++)
                {
                    table[i][left_column] = 0.00;
                }
            }
            else
            {
                for (i = left_column; i <= right_column; i++)
                {
                    table[left_bound_Num - 1][i] = 0.00;
                }
            }
        }
        else if (strcmp(operator, "INS") == 0)
        {
            if (inbuf[4] == inbuf[7])
            {
                for (i = left_bound_Num - 1; i < right_bound_Num; i++)
                {
                    table[i][left_column] = insertNum;
                }
            }
            else
            {
                for (i = left_column; i <= right_column; i++)
                {
                    table[left_bound_Num - 1][i] = insertNum;
                }
            }
        }
        printf("\t A\t B\t C\t D\t E\n");
        for (i = 0; i < row; i++)
        {
            printf("%i\t", i + 1);
            for (j = 0; j < col; j++)
            {
                printf("%.2f\t", table[i][j]);
            }
            printf("\n");
        }

        printf("Please enter the command and do some math: (ADD, MUL, DEL, INS)\n");
        printf("Or you can enter the quit if want to exit.\n");
        fgets(inbuf, size, stdin);
        sscanf(inbuf, "%c", inbuf);
    } while (strcmp(inbuf, "quit\n") != 0);

    return 0;
}